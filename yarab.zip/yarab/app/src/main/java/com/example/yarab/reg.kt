package com.example.yarab
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.yarab.databinding.ActivityLoginBinding
import com.example.yarab.databinding.ActivityRegBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class reg : AppCompatActivity() {
    private lateinit var mAuth: FirebaseAuth
    private lateinit var binding : ActivityRegBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRegBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mAuth = FirebaseAuth.getInstance()
        binding.regester.setOnClickListener {

        val name = binding.name.text.toString()
        val email = binding.email.text.toString()
        val pass = binding.password.text.toString()
        if (email.isEmpty()) {
            binding.name.error = "name required"
            binding.name.requestFocus()

        } else if (email.isEmpty()) {
            binding.email.error = "email required"
            binding.email.requestFocus()

        } else if (pass.isEmpty()) {
            binding.password.error = "password required"
            binding.password.requestFocus()

        } else {
            mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener {
                if (it.isSuccessful) {
                    Toast.makeText(this, "register succesful", Toast.LENGTH_SHORT).show()
                    finish()
                    startActivity(Intent(reg@this, LoginActivity::class.java))

                } else {
                    Toast.makeText(this, "register unsuccesful", Toast.LENGTH_LONG).show()

                }
            }

        }

    }
    }

}



