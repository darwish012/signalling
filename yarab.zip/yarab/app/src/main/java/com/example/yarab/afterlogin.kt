package com.example.yarab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class afterlogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_afterlogin)
    }
}